
/**
 * Write a description of class ErasablePen here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ErasablePen extends Pen
{    
	/**
	 * This method simulates the pencil erasing somethig
	 *
	 * @param 	words		The words the pencil erased
	 */

	private String inkColor;
    
       
   /**
    * Constructor for a Pen object. It allows you specify the color of the ink, the material it is made of,
    * and the size of the writing tip
    *
    * @param	inkColor			the color of the ink
    * @param 	bodyMaterial	The pen's material. It must be one of "plastic", "metal", or "wooden"
    * @param 	tipSize			The size of the point in millimeters (must be positive)
	  */
   public ErasablePen(String inkColor, String bodyMaterial, double tipSize)
   {
	   	 super(inkColor, bodyMaterial, tipSize);
 	     
   }

       
  
	   /**
	    * The default constructor for a pen. It creates a plastic pen that writes in purple with a 0.5mm tip
	    */
	   public ErasablePen()
	   {
			  this("purple", "plastic", 0.5);

	   }


	public void erase(String words)
	{
		System.out.println("The "  + inkColor + " " + getBodyMaterial() + " pencil just erased the words: " + words);
	}
  
    
}
